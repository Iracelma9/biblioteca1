package IP.sintaxy.Service;

import IP.sintaxy.Modeles.Emprestimo;
import IP.sintaxy.Repository.EmprestimoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmprestimoSrvice {
    @Autowired
    private EmprestimoRepository emprestimoRepository;
    public Emprestimo criarEmprestimo(Emprestimo emprestimo){
        return emprestimoRepository.save(emprestimo);
    }
    public List<Emprestimo> listarEmprestimo(){
        return  emprestimoRepository.findAll();
    }
    public Emprestimo obterEmprestimo(Long id){
        return emprestimoRepository.findById(id).orElse(null);
    }
    public Emprestimo atualizarEmprestimo(Long id,Emprestimo emprestimoAtualizado){
        Emprestimo emprestimo =obterEmprestimo(id);
        if (emprestimo!=null){
            emprestimo.setLivro(emprestimoAtualizado.getLivro());
            emprestimo.setUsuario(emprestimoAtualizado.getUsuario());
            emprestimo.setDataEmprestimo(emprestimoAtualizado.getDataEmprestimo());
            emprestimo.setDataDevolucao(emprestimoAtualizado.getDataDevolucao());
            return emprestimoRepository.save(emprestimo);
        }
        return  null;
    }
    public void deletarEmprestimo(Long id){
        emprestimoRepository.deleteById(id);
    }
}
