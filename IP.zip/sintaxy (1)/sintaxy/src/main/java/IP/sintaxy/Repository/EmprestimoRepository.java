package IP.sintaxy.Repository;

import IP.sintaxy.Modeles.Emprestimo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmprestimoRepository extends JpaRepository<Emprestimo, Long> {
}
