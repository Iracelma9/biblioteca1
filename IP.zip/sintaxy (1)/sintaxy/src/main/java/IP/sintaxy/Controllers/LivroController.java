package IP.sintaxy.Controllers;

import IP.sintaxy.Modeles.Livro;
import IP.sintaxy.Service.LivroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/livros")
public class LivroController {
    @Autowired
    private LivroService livroService;
    @PostMapping("/criar")
    public Livro criarLivro(@RequestBody Livro livro){
        return livroService.criarLivro(livro);
    }
    @GetMapping("/listar")
    public List<Livro> listarLivros(){
        return livroService.listarLivro();
    }
    @GetMapping("/atualizar/{id}")
    public Livro atualizarLivro(@PathVariable Long id,@RequestBody Livro livro){
        return livroService.atualizarLivro(id, livro);
    }
    @DeleteMapping("/deletar/{id}")
    public void deletarLivro(@PathVariable Long id){
        livroService.deletarLivro(id);
    }
}
