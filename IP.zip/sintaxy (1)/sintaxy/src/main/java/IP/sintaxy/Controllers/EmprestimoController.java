package IP.sintaxy.Controllers;

import IP.sintaxy.Modeles.Emprestimo;
import IP.sintaxy.Service.EmprestimoSrvice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/emprestimo")
public class EmprestimoController {


    @Autowired
    private EmprestimoSrvice emprestimoSrvice;


    @PostMapping ("/criar")
    public Emprestimo criarEmprestimo(@RequestBody Emprestimo emprestimo){
        return emprestimoSrvice.criarEmprestimo(emprestimo);
    }


    @GetMapping("/listar")
    public List<Emprestimo>listarEmprestimo(){
        return emprestimoSrvice.listarEmprestimo();
    }

    @GetMapping("/{id}")
    public  Emprestimo obterEmprestimo(@PathVariable Long id){
        return emprestimoSrvice.obterEmprestimo(id);
    }
    @PutMapping("/atualizar/{id}")
public Emprestimo atualizarEmprestimo(@PathVariable Long id,@RequestBody Emprestimo emprestimo){
        return emprestimoSrvice.atualizarEmprestimo(id, emprestimo);
    }
    @DeleteMapping("/deletar/{id}")
    public void deletarEmprestimo(@PathVariable Long id){
        emprestimoSrvice.deletarEmprestimo(id);
    }


}
