package IP.sintaxy.Modeles;
public @interface Enity {
}
