package IP.sintaxy.Service;

import IP.sintaxy.Modeles.Role;
import IP.sintaxy.Modeles.Usuario;
import IP.sintaxy.Repository.RoleRepository;
import IP.sintaxy.Repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class UsuarioService {
    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private RoleRepository roleRepository;

    public Usuario criarUsuario(Usuario usuario, Set<String> roleNames) {
        Set<Role> roles = new HashSet<>();
        for (String roleName : roleNames) {
            Role role = roleRepository.findByName(roleName);
            if (role != null) {
                roles.add(role);
            }
        }
        usuario.setRoles(roles);
        return usuarioRepository.save(usuario);
    }

    public List<Usuario> listarUsuarios() {
        return usuarioRepository.findAll();
    }

    public Usuario obterUsuario(Long id) {
        return usuarioRepository.findById(id).orElse(null);
    }

    public Usuario atualizarUsuario(Long id, Usuario usuarioAtualizado, Set<String> roleNames) {
        Usuario usuario = obterUsuario(id);
        if (usuario != null) {
            usuario.setUsername(usuarioAtualizado.getUsername());
            usuario.setPassword(usuarioAtualizado.getPassword());

            Set<Role> roles = new HashSet<>();
            for (String roleName : roleNames) {
                Role role = roleRepository.findByName(roleName);
                if (role != null) {
                    roles.add(role);
                }
            }
            usuario.setRoles(roles);
            return usuarioRepository.save(usuario);
        }
        return null;
    }

    public void deletarUsuario(Long id) {
        usuarioRepository.deleteById(id);
    }
}
