package IP.sintaxy.Service;

import IP.sintaxy.Modeles.Livro;
import IP.sintaxy.Repository.LivroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LivroService {
    @Autowired
    private LivroRepository livroRepository;
    private Object livro;

    public Livro criarLivro(Livro livro){
        return livroRepository.save(livro);
    }
    public List<Livro> listarLivro(){
        return livroRepository.findAll();
    }
    public Livro obeterLivro(Long id){
        return livroRepository.findById(id).orElse(null);
    }
    public  Livro atualizarLivro (Long id,Livro livroAtualizado) {
        Livro livro = obeterLivro(id);
        if (livro != null) {

            livro.setTitulo(livroAtualizado.getTitulo());
            livro.setAutor(livroAtualizado.getAutor());
            return livroRepository.save(livro);
        }
        return null;
    }
    public  void deletarLivro (Long id){
        livroRepository.deleteById(id);
    }

}
