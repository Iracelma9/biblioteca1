package IP.sintaxy.Controllers;

import IP.sintaxy.Modeles.Usuario;
import IP.sintaxy.Service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    @PostMapping("/criar")
    public Usuario criarUsuario(@RequestBody Usuario usuario, @RequestParam Set<String> roles) {
        return usuarioService.criarUsuario(usuario, roles);
    }

    @GetMapping("/listar")
    public List<Usuario> listarUsuarios() {
        return usuarioService.listarUsuarios();
    }

    @GetMapping("/{id}")
    public Usuario obterUsuario(@PathVariable Long id) {
        return usuarioService.obterUsuario(id);
    }

    @PutMapping("/atualizar/{id}")
    public Usuario atualizarUsuario(@PathVariable Long id, @RequestBody Usuario usuario, @RequestParam Set<String> roles) {
        return usuarioService.atualizarUsuario(id, usuario, roles);
    }

    @DeleteMapping("/deletar/{id}")
    public void deletarUsuario(@PathVariable Long id) {
        usuarioService.deletarUsuario(id);
    }
}
