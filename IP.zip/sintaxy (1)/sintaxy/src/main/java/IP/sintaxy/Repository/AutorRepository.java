package IP.sintaxy.Repository;

import IP.sintaxy.Modeles.Autor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AutorRepository extends JpaRepository<Autor, Long> {
}
