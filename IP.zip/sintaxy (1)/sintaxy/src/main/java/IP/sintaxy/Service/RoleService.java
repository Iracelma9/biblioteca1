package IP.sintaxy.Service;


import IP.sintaxy.Modeles.Role;
import IP.sintaxy.Repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RoleService {

    @Autowired
    private RoleRepository roleRepository;

    public Role criarRole(Role role) {
        return roleRepository.save(role);
    }

    public Role encontrarPorNome(String nome) {
        return roleRepository.findByName(nome);
    }
}
