package IP.sintaxy.Repository;

import IP.sintaxy.Modeles.Livro;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LivroRepository extends JpaRepository<Livro, Long> {
}
