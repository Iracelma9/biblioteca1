package IP.sintaxy.Service;

import IP.sintaxy.Modeles.Autor;
import IP.sintaxy.Repository.AutorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AutorService {

    @Autowired
    private AutorRepository autorRepository;

    public Autor criarAutor(Autor autor) {
        return autorRepository.save(autor);
    }

    public List<Autor> listarAutores() {
        return autorRepository.findAll();
    }

    public Autor obterAutor(Long id) {
        return autorRepository.findById(id).orElse(null);
    }

    public Autor atualizarAutor(Long id, Autor autorAtualizado) {
        Autor autor = obterAutor(id);
        if (autor != null) {
            autor.setNome(autorAtualizado.getNome());
            autor.setLivros(autorAtualizado.getLivros());

        }
        return null;
    }

    public void deletarAutor(Long id) {
        autorRepository.deleteById(id);
    }
}
