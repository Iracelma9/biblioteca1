package IP.sintaxy.Controllers;

import IP.sintaxy.Modeles.Autor;
import IP.sintaxy.Service.AutorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/autores")
public class AutorController {
    @Autowired
    private AutorService autorService ;
    @PostMapping("/criar")
    public Autor criarAutor (@RequestBody Autor autor){
        return  autorService.criarAutor(autor);
    }
    @GetMapping("/listar")
    public List<Autor>listarAutor(){
        return  autorService.listarAutores();
    }
    @GetMapping("/{id}")
    public Autor obterAutor(@PathVariable Long id){
        return autorService.obterAutor(id);
    }
    @PutMapping("/atualizar/{id}")
public  Autor atualizarAutor(@PathVariable Long id,Autor autor){
        return autorService.atualizarAutor(id, autor);
    }
    @DeleteMapping("/deletar/{id}")
    public void deletarAutor(@PathVariable Long id){
        autorService.deletarAutor(id);
    }

}
